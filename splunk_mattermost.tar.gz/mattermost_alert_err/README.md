# Mattermost APP for Splunk

Now an app that can monitor errors in `savedsearches.conf` and push them to a Mattermost channel.



